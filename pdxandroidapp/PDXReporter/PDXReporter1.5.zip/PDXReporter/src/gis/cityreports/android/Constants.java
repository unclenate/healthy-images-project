package gis.cityreports.android;

/**
 * @author Roy Cham
 * 
 * Copyright 2010 City of Portland. All rights reserved.
 *
 */
public class Constants {
	public static final String LOGTAG = "PDXReporter";
}
